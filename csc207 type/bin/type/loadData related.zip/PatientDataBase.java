package type;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class PatientDataBase {

	private HashMap<String, Patient> patientMap;

	public PatientDataBase() {
		patientMap = new HashMap<String, Patient>();
	}

	public void addNewPatient(String cardNumber, Patient patient) {
		patientMap.put(cardNumber, patient);
	}

	/**
	 * Writes the values to file outputStream: one per line, comma separated.
	 * 
	 * @param outputStream
	 *            the output stream to write the records to
	 */
	//modified from lecture notes.
	public void saveToFile(FileOutputStream outputStream) {
		try {
			Iterator<Patient> it = patientMap.values().iterator();
			// write record info one per line into outputStream
			while (it.hasNext()) {
				Patient currentPatient = it.next();
				outputStream.write((currentPatient.toString() + "\n")
						.getBytes());
				System.out.println(currentPatient.toString());
				System.out.println(patientMap.size());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//modified from lecture notes.
	public void readFromFile(String filePath) throws FileNotFoundException {
		Scanner scanner = new Scanner(new FileInputStream(filePath));
		String[] record;
		while (scanner.hasNextLine()) {
			record = scanner.nextLine().split("~");
			Patient newPatient = Patient.scan(record);
			String cardNumber = record[2];
			patientMap.put(cardNumber, newPatient);
		}
		scanner.close();
	}

	public Patient getPatientByCardNumber(String cardNumber) {
		return patientMap.get(cardNumber);
	}


}
