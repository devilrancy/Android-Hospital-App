package type;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

public class Patient {
	// On second thought, I think the vitalSigns should be a private variable
	// belongs to patient, which records the historical records.
	private VitalSign vitalSigns;

	// only created for testing purpose.
	private String name;
	private String dob;
	private String cardNumber;
	private Calendar arrivalTime;
	//
	private DateFormat dateFormat;

	// symptons should not be included in vital signs.
	// See https://piazza.com/class/hkcz8oq9qli5tv?cid=619
	private List<String> symptoms;

	// constructor
	public Patient(String name, String dob, String cardNumber,
			Calendar arrivalTime) {
		this.name = name;
		this.dob = dob;
		this.cardNumber = cardNumber;
		this.arrivalTime = arrivalTime;
		this.dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		this.symptoms = new LinkedList<String>();
		this.vitalSigns = new VitalSign();
		return;
	}

	// additional constructor if vitalsigns are provided.
	public Patient(String name, String dob, String cardNumber,
			Calendar arrivalTime, VitalSign vitalSign) {
		this.name = name;
		this.dob = dob;
		this.cardNumber = cardNumber;
		this.arrivalTime = arrivalTime;
		this.dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		this.symptoms = new LinkedList<String>();
		this.vitalSigns = vitalSign;
		return;
	}

	// update the vital sign of this patient.
	// call the Add method of vital sign.
	public void setVitalSign(Integer newBloodPressure, Double newTemperature,
			Integer newHeartRate) {
		vitalSigns.addBloodPressure(newBloodPressure);
		vitalSigns.addHeartRate(newHeartRate);
		vitalSigns.addTemperature(newTemperature);
		vitalSigns.addTimeStamp(Calendar.getInstance());
		return;
	}

	public void setSymptoms(String newSymptoms) {
		symptoms.add(newSymptoms);
		return;
	};

	public List<String> getAllSymptoms() {
		return symptoms;
	};

	// print info of patient, divided by ~
	public String toString() {
		return name + "~" + dob + "~" + cardNumber + "~"
				+ dateFormat.format(arrivalTime.getTime()) + "~"
				+ vitalSigns.toString();
	}

	// this method helps to transform the scanned information from text file
	// into a new patient object.
	public static Patient scan(String[] input) {
		Patient patient;

		Calendar arrivalTime = Calendar.getInstance();
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

		try {
			arrivalTime.setTime(format.parse(input[3]));

			// if the vital signs are not provided, input length should be 4.
			if (input.length == 4) {
				patient = new Patient(input[0], input[1], input[2], arrivalTime);
				return patient;
				// if the vital signs are provided, input length should be 5.
			} else if (input.length == 5) {
				String[] input2 = input[4].split("#");
				System.out.println(input2[0]);
				// get the content of bloodPressure as a string like: "109"
				// "110"
				String bloodPressureString = input2[0].substring(1,
						input2[0].length() - 1);
				String temperatureString = input2[1].substring(1,
						input2[1].length() - 1);
				String heartRateString = input2[2].substring(1,
						input2[2].length() - 1);
				String timeStampsString = input2[3].substring(1,
						input2[3].length() - 1);

				List<Integer> bloodPressure = new ArrayList<Integer>();
				List<Double> temperature = new ArrayList<Double>();
				List<Integer> heartRate = new ArrayList<Integer>();
				List<Calendar> timeStamps = new ArrayList<Calendar>();

				// transform the string into Integer/double/calendar
				for (String str : Arrays.asList(bloodPressureString
						.split("\\s*,\\s*")))
					bloodPressure.add(Integer.parseInt(str));
				for (String str : Arrays.asList(temperatureString
						.split("\\s*,\\s*")))
					temperature.add(Double.parseDouble(str));
				for (String str : Arrays.asList(heartRateString
						.split("\\s*,\\s*")))
					heartRate.add(Integer.parseInt(str));
				for (String str : Arrays.asList(timeStampsString
						.split("\\s*,\\s*"))) {
					arrivalTime.setTime(format.parse(str));
					timeStamps.add(arrivalTime);
				}

				// create the vital sign of this patient
				VitalSign vitalSign = new VitalSign(bloodPressure, temperature,
						heartRate, timeStamps);

				// create a new patient object according to basic info and vital
				// signs
				patient = new Patient(input[0], input[1], input[2],
						arrivalTime, vitalSign);
				return patient;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) {
		// for testing purpose.

		PatientDataBase patientDatabase = new PatientDataBase();

		// test object 1
		Patient patient = new Patient("Eric Lin", "1992-10-19", "A1001",
				Calendar.getInstance());
		patient.setVitalSign(110, 37.5, 90);
		patient.setSymptoms("All good!");
		patient.setVitalSign(120, 39.0, 91);
		patient.setSymptoms("High Temperature!");

		// test object 2
		Patient patient2 = new Patient("Eric William", "1993", "A1002",
				Calendar.getInstance());
		patient2.setVitalSign(109, 37.0, 88);
		patient2.setSymptoms("Very health!");
		
		File file = new File("/h/u13/c3/00/c3linhai/csc207/output.txt");
		try {
			//comment these two lines if you want to test patientDatabase.readFromFile
			patientDatabase.addNewPatient("A1001", patient);
			patientDatabase.addNewPatient("A1002", patient2);
			
			FileOutputStream ostream = new FileOutputStream(file);
			patientDatabase.saveToFile(ostream);
			// the path of output file can be modified as you like =)
			patientDatabase
					.readFromFile("/h/u13/c3/00/c3linhai/csc207/output.txt");
			//test if the patient is successfully loaded from the text file
			System.out.println(patientDatabase.getPatientByCardNumber("A1001")
					.toString());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}