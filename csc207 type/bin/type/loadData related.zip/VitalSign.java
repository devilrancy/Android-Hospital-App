package type;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class VitalSign {

	// the bloodPressure, temperature and heartRate can be traced since they
	// share the same index with timeStamps.
	private List<Integer> bloodPressure;
	private List<Double> temperature;
	private List<Integer> heartRate;
	private List<Calendar> timeStamps;
	private DateFormat dateFormat;

	//constructor
	public VitalSign() {
		this.bloodPressure = new ArrayList<Integer>();
		this.temperature = new ArrayList<Double>();
		this.heartRate = new ArrayList<Integer>();
		this.timeStamps = new ArrayList<Calendar>();
		this.dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		return;
	}

	//constructor
	public VitalSign(List<Integer> bloodPressure, List<Double> temperature,
			List<Integer> heartRate, List<Calendar> timeStamps) {
		this.bloodPressure = bloodPressure;
		this.temperature = temperature;
		this.heartRate = heartRate;
		this.timeStamps = timeStamps;
		this.dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		return;
	}

	public void addBloodPressure(Integer newBloodPressure) {
		bloodPressure.add(newBloodPressure);
		return;
	};

	public void addTemperature(Double newTemperature) {
		temperature.add(newTemperature);
		return;
	};;

	public void addHeartRate(Integer newHeartRate) {
		heartRate.add(newHeartRate);
		return;
	};

	public void addTimeStamp(Calendar newTimeStamp) {
		timeStamps.add(newTimeStamp);
		return;
	};

	public List<Integer> getAllBloodPressure() {
		return bloodPressure;
	};

	public List<Double> getAllTemperature() {
		return temperature;
	};

	public List<Integer> getAllHeartRate() {
		return heartRate;
	};

	public String toString() {
		return bloodPressure.toString() + "#" + temperature.toString() + "#"
				+ heartRate.toString() + "#" + timeToString();
	}
	
	public String timeToString() {
		String timeString = "[";
		for (Calendar timeStamp : timeStamps)
			timeString += dateFormat.format(timeStamp.getTime()) + ", ";
		timeString = timeString.substring(0, timeString.length() - 2);
		timeString += "]";
		return timeString;
	}

}
